/**
 * @author bfhurley
 */
package edu.iastate.cs2280.hw3;

import java.util.AbstractSequentialList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * An implementation of the List interface that uses a doubly-linked list of
 * "pages" (nodes), where each page stores multiple items in an array.
 * * This structure is optimized for fast, $O(\log N_{\text{pages}})$
 * index-based access (get, set) and iterator initialization. It achieves this
 * using a separate `ArrayList` (`pageIndex`) that acts as a top-level index,
 * allowing binary search to quickly find the correct page for a given logical
 * index.
 * * Structural modifications (add(int, E), remove(int)) are
 * $O(N_{\text{pages}})$ in the worst case. While finding the target page is
 * fast ($O(\log N_{\text{pages}})$), these operations must update the logical
 * indices of all subsequent pages in the `pageIndex`, which requires a linear
 * scan of the index. This is still significantly faster than a standard
 * `LinkedList` ($O(N)$) for modifications in the middle of the list.
 * * This implementation includes page-splitting (when a page becomes full) and
 * page-merging/rebalancing (when a page becomes under-filled) to maintain
 * efficiency.
 *
 * @param <E> the type of elements in this list
 */
public class IndexedPagedList<E> extends AbstractSequentialList<E> implements List<E> {

  /**
   * Default capacity for each page (node).
   */
  private static final int PAGE_CAPACITY = 4;

  /**
   * The minimum number of items a page must have. If a page's count drops
   * below this, it will trigger a merge or rebalance.
   */
  private static final int HALF_CAPACITY = PAGE_CAPACITY / 2;
  /**
   * A static, reusable comparator for performing binary searches on the
   * `pageIndex`. It compares an `IndexEntry` from the list (the first argument)
   * with a logical index (the "key", or second argument).
   */
  private static final Comparator<Object> INDEX_COMPARATOR = new Comparator<Object>() {
    /**
     * Compares an IndexEntry (from the list) to a logical index (the key).
     *
     * @param entryObj The IndexEntry (cast from Object) from the list.
     * @param key      The logical index (Integer) we are searching for.
     * @return a negative integer, zero, or a positive integer as the
     *         entry's logical index is less than, equal to, or greater than the
     *         key.
     */
    @Override
    public int compare(Object entryObj, Object key) {
      @SuppressWarnings("unchecked") IndexEntry<?> entry = (IndexEntry<?>) entryObj;
      Integer logicalIndex = (Integer) key;
      return entry.logicalIndex.compareTo(logicalIndex);
    }
  };
  /**
   * The dummy head node of the doubly-linked list of pages.
   */
  private final Page<E> head;
  /**
   * The dummy tail node of the doubly-linked list of pages.
   */
  private final Page<E> tail;
  /**
   * The "fast-lane" index. This `ArrayList` stores an `IndexEntry` for
   * *every* data page in the list. It allows for $O(\log N_{\text{pages}})$
   * binary search
   * to find the page corresponding to a given logical index.
   * * This index *must* be kept in sync with the linked list of pages.
   */
  private final ArrayList<IndexEntry<E>> pageIndex;
  /**
   * The total number of elements stored in the list.
   */
  private int totalSize;
  /**
   * A counter for structural modifications (add, remove). Used by the
   * iterator to detect concurrent modifications and fail-fast.
   */
  private int modificationCount;

  /**
   * Constructs a new, empty IndexedPagedList.
   * Initializes the dummy head and tail nodes and the empty page index.
   */
  public IndexedPagedList() {
	  this.totalSize = 0;
	  this.modificationCount = 0;
	  head = new Page<E>(null,null);
	  tail = new Page<E>(this.head, null);
	  head.next = this.tail;
	  pageIndex = new ArrayList<>();
  }

  /**
   * Returns the number of elements in this list.
   *
   * @return the number of elements in this list
   */
  @Override
  public int size() {
    return totalSize;
  }

  /**
   * Appends the specified element to the end of this list.
   * * This operation is $O(N_{\text{pages}})$ in the worst case, identical to
   * add(size(), item).
   *
   * @param item element to be appended to this list
   * @return {@code true} (as specified by List#add)
   * @throws NullPointerException if the specified element is null
   */
  @Override
  public boolean add(E item) {
	  add(totalSize , item);
		 return true; 
  }

  /**
   * Inserts the specified element at the specified position in this list.
   * * This operation is $O(N_{\text{pages}})$ in the worst case.
   * Finding the insertion point is fast ($O(\log N_{\text{pages}})$),
   * but updating the `pageIndex` after the insertion requires a
   * linear scan of the index ($O(N_{\text{pages}})$).
   * * This method performs the following steps:
   * 1. Finds the target page and offset for insertion using findPageForLogicalIndex.
   * 2. Increment modCount, totalSize.
   * 3. Handles three cases:
   * - List is empty: Creates a new page.
   * - Target page has space: Adds the item.
   * - Target page is full: Performs a <b>split</b> operation.
   * 4. Updates the `pageIndex` to reflect changes in page counts,
   * new pages, and subsequent logical indices.
   *
   * @param pos  the index at which the specified element is to be inserted
   * @param item the element to be inserted
   * @throws NullPointerException      if the specified element is null
   * @throws IndexOutOfBoundsException if the index is out of range
   *                                   ({@code pos < 0 || pos > size()})
   */
  @Override
  public void add(int pos, E item) {
	  if (item == null) {
		  throw new NullPointerException();
	  }
	  if(pos < 0 || pos > size()) {
		  throw new IndexOutOfBoundsException();
	  }
	  //an empty list
	  if(totalSize == 0) {
		 Page<E> page = new Page<E>(head,tail);
		 head.next = page;
		 tail.prev = page;
		 page.addItem(0, item);
		 IndexEntry<E> entry = new IndexEntry<>(page, 0, 1);
		 pageIndex.add(entry);
		 totalSize++;
		 modificationCount++;
		 return;
	  }
	  //not empty, but not full
	  PageInfo<E> info = findPageForLogicalIndex(pos);
	  int offset = info.offset;
	  Page<E> page = info.page;
	  if(page.count < PAGE_CAPACITY) {
		  page.addItem(offset, item);
		  int indexInList = findIndexInPageIndex(page);
		  pageIndex.get(indexInList).count++;
		  updatePageIndex(indexInList + 1, 1);
		  totalSize++;
		  modificationCount++;
		  return;
	  }
	  // full page, move things
	  Page<E> newPage = new Page<E>(page, page.next);
	  page.next = newPage;
	  newPage.next.prev = newPage;
	  for(int i = 0; i < HALF_CAPACITY; i++) {
		 E newItem = page.removeItem(HALF_CAPACITY);
		  newPage.addItem(i, newItem);
	  }
	  int indexInList = findIndexInPageIndex(page);
	  IndexEntry<E> oldEntry = pageIndex.get(indexInList);
	  oldEntry.count = HALF_CAPACITY;
	  
	  int pagePos = findIndexInPageIndex(page);
	  IndexEntry<E> newEntry = new IndexEntry<>(newPage,(oldEntry.logicalIndex + HALF_CAPACITY),HALF_CAPACITY);
	  pageIndex.add(indexInList + 1, newEntry);
	  
	  if(pos < newEntry.logicalIndex) {
		  page.addItem(pos - oldEntry.logicalIndex, item);
		  oldEntry.count++;
		  updatePageIndex(indexInList + 1,1);
	  } else {
		  newPage.addItem(pos - newEntry.logicalIndex, item);
		  newEntry.count++;
		  updatePageIndex(indexInList + 2,1);
	  }
	  totalSize++;
	  modificationCount++;
  }

  /**
   * Removes the element at the specified position in this list.
   * * This operation is $O(N_{\text{pages}})$ in the worst case.
   * Finding the element is fast ($O(\log N_{\text{pages}})$),
   * but updating the `pageIndex` after the removal (and any potential
   * merge) requires a linear scan of the index ($O(N_{\text{pages}})$).
   * * This method performs the following steps:
   * 1. Finds the target page and offset for removal using findPageForLogicalIndex.
   * 2. Increment modCount, decrement totalSize.
   * 2. Removes the item from the page's array.
   * 3. If the page's count drops below `HALF_CAPACITY`, it triggers:
   * - <b>Rebalance:</b> If the *successor* page has items to spare,
   * one item is moved to the current page.
   * - <b>Full Merge:</b> If the *successor* page does not have items
   * to spare, all items from the successor are moved to the
   * current page, and the successor page is removed.
   * 4. Updates the `pageIndex` to reflect all changes.
   * 5. Make sure to handle the edge case of page becoming empty AND it's the last page.
   *
   * @param pos the index of the element to be removed
   * @return the element previously at the specified position
   * @throws IndexOutOfBoundsException if the index is out of range
   *                                   ({@code pos < 0 || pos >= size()})
   */
  @Override
  public E remove(int pos) {
	  if(pos < 0 || pos >= size()) {
		  throw new IndexOutOfBoundsException();
	  }
	  PageInfo<E> info = findPageForLogicalIndex(pos);
	  E item = info.page.removeItem(info.offset);
	  modificationCount++;
	  totalSize--;
	  int index = findIndexInPageIndex(info.page);
	  pageIndex.get(index).count--;
	  
	  if(info.page.count < HALF_CAPACITY) {
		  Page<E> next = info.page.next;
		  if(next == tail) {
			  if(info.page.count == 0) {
				  info.page.prev.next = info.page.next;
				  info.page.next.prev = info.page.prev;
				  pageIndex.remove(index);
			  }
		  } else {
			  //rebalance
			 if(next.count > HALF_CAPACITY) {
				 E movedItem = next.removeItem(0);
				 info.page.addItem(info.page.count, movedItem);
				 
				 pageIndex.get(index).count++;
				 
				 IndexEntry<E> nextEntry = pageIndex.get(index + 1);
				 nextEntry.count--;
				 nextEntry.logicalIndex++;
			 }
			 	// merge
			 else {
				 int itemsMove = next.count;
				 for(int i = 0; i < itemsMove; i++) {
					 E movedItem = next.removeItem(0);
					 info.page.addItem(info.page.count, movedItem);
				 }
				 info.page.next = next.next;
				 next.next.prev = info.page;
				 
				 pageIndex.get(index).count += itemsMove;
				 pageIndex.remove(index + 1);
			 }
		  }
	  }
	  updatePageIndex(index + 1, -1);
	  
	  return item;
  }

  /**
   * Returns a list iterator over the elements in this list (in proper
   * sequence), starting at the specified position in the list.
   * * The iterator is initialized in $O(\log N_{\text{pages}})$ time by using
   * `findPageForLogicalIndex` to immediately seek to the correct starting
   * page and offset.
   *
   * @param pos the index of the first element to be returned from the
   *            list iterator (by a call to ListIterator#next)
   * @return a list iterator over the elements in this list (in proper
   * sequence), starting at the specified position in the list
   * @throws IndexOutOfBoundsException if the index is out of range
   *                                   ({@code pos < 0 || pos > size()})
   */
  @Override
  public ListIterator<E> listIterator(int pos) {
	  return new PagedListIterator(pos);
  }

  // --- Private Helper Methods and Classes ---

  /**
   * Finds the page and in-page offset for a given logical index.
   * * This method runs in $O(\log N_{\text{pages}})$ time by performing a
   * binary search on the `pageIndex`.
   * * This method performs the following steps:
   * 1. Preform a binary search on the `pageIndex` using Collections.binarySearch with INDEX_COMPARATOR.
   * 2. Handle cases for index >= 0, index < 0.
   * 3. Calculate the offset within the page's array.
   * 4. Return the page and offset.
   *
   * @param pos The logical index to find.
   * @return A PageInfo object containing the page and offset.
   */
  private PageInfo<E> findPageForLogicalIndex(int pos) {
	  int foundIndex = Collections.binarySearch(pageIndex, pos, INDEX_COMPARATOR);
	  
      if (foundIndex < 0) {
          foundIndex = (-foundIndex - 2);
      }
      
      IndexEntry<E> entry = pageIndex.get(foundIndex);
      Page<E> page = entry.page;
      int offset = pos - entry.logicalIndex;
      
      return new PageInfo<E>(page, offset);
  }

  /**
   * Finds the index (in the `pageIndex` `ArrayList`) of the `IndexEntry`
   * that corresponds to the given `page`.
   * * This is an $O(N_{\text{pages}})$ operation (linear scan). It is only
   * called by `add` and `remove`, which are already $O(N_{\text{pages}})$
   * due to `updatePageIndex`.
   *
   * @param page The page to find.
   * @return The index in `pageIndex`, or -1 if not found.
   */
  private int findIndexInPageIndex(Page<E> page) {
	  for (int i = 0; i < pageIndex.size(); i++) {
	        if (pageIndex.get(i).page == page) {
	            return i;
	        }
	    }
	    return -1;
  }

  /**
   * Updates the `logicalIndex` of all `IndexEntry` objects in the
   * `pageIndex` starting from `startIndex`, adding `delta` to each.
   * * This is an $O(N_{\text{pages}})$ operation and is the reason why
   * `add` and `remove` are not $O(\log N)$.
   *
   * @param startIndex The index in `pageIndex` to start updating from.
   * @param delta      The amount to add to each `logicalIndex` (e.g., +1 or -1).
   */
  private void updatePageIndex(int startIndex, int delta) {
	  for(int i = startIndex; i < pageIndex.size(); i++) {
		  IndexEntry<E> entry = pageIndex.get(i);
		  entry.logicalIndex += delta;
	  }
  }

  /**
   * Returns a string representation of the internal structure of the list.
   * This string shows the contents of each page (node) and uses "-"
   * to represent empty slots in each page's array.
   *
   * @return A string in the format [(item1, item2, -, -), (item3, -, -, -)]
   */
  public String toStringInternal() {
    StringBuilder sb = new StringBuilder();
    sb.append("[");

    Page<E> currentPage = head.next;
    while (currentPage != tail) {
      sb.append("(");
      for (int i = 0; i < PAGE_CAPACITY; i++) {
        if (i < currentPage.count) {
          sb.append(currentPage.items[i]);
        } else {
          sb.append("-");
        }

        if (i < PAGE_CAPACITY - 1) {
          sb.append(", ");
        }
      }
      sb.append(")");
      if (currentPage.next != tail) {
        sb.append(", ");
      }
      currentPage = currentPage.next;
    }

    sb.append("]");
    return sb.toString();
  }

  /**
   * Returns a string representation of the internal structure of the list,
   * including the position of a ListIterator's cursor.
   *
   * The cursor position (represented by "|") is determined by the
   * iterator's `nextIndex()` method.
   *
   * @param iter The ListIterator to visualize.
   * @return A string showing page contents and the iterator's cursor position.
   */
  public String toStringInternal(ListIterator<E> iter) {
    // Find the logical position of the iterator's cursor
    int logicalIndex = iter.nextIndex();
    // Find the physical page and offset that correspond to that logical index
    PageInfo<E> cursorInfo = findPageForLogicalIndex(logicalIndex);
    Page<E> cursorPage = cursorInfo.page;
    int cursorOffset = cursorInfo.offset;

    StringBuilder sb = new StringBuilder();
    sb.append("[");

    Page<E> currentPage = head.next;
    while (currentPage != tail) {
      sb.append("(");
      for (int i = 0; i < PAGE_CAPACITY; i++) {
        // Check if the cursor should be printed *before* this item
        if (currentPage == cursorPage && i == cursorOffset) {
          sb.append("| ");
        }

        if (i < currentPage.count) {
          sb.append(currentPage.items[i]);
        } else {
          sb.append("-");
        }

        if (i < PAGE_CAPACITY - 1) {
          sb.append(", ");
        }
      }
      sb.append(")");
      if (currentPage.next != tail) {
        sb.append(", ");
      }
      currentPage = currentPage.next;
    }

    // Handle case where cursor is at the very end of the list (pos == totalSize)
    if (cursorPage == tail) {
      sb.append(", (| -)");
    }

    sb.append("]");
    return sb.toString();
  }

  /**
   * A private static inner class representing a "page" (node) in the
   * doubly-linked list. Each page holds an array of items.
   */
  private static class Page<E> {
    /**
     * The array holding the data items.
     */
    final E[] items;

    /**
     * The number of items currently stored in this page.
     */
    int count;

    /**
     * The link to the previous page in the list.
     */
    Page<E> prev;

    /**
     * The link to the next page in the list.
     */
    Page<E> next;

    /**
     * Constructs a new page.
     *
     * @param prev The previous page.
     * @param next The next page.
     */
    @SuppressWarnings("unchecked")
    Page(Page<E> prev, Page<E> next) {
      this.items = (E[]) new Object[PAGE_CAPACITY];
      this.count = 0;
      this.prev = prev;
      this.next = next;
    }

    /**
     * Inserts an item into this page's array at a specific offset.
     * Shifts existing items to the right.
     *
     * @param offset The index in the `items` array to insert at.
     * @param item   The item to insert.
     */
    void addItem(int offset, E item) {
      if (offset < 0 || offset > count) {
        throw new IndexOutOfBoundsException("Internal add error: offset " + offset + ", count " + count);
      }
      System.arraycopy(items, offset, items, offset + 1, count - offset);
      items[offset] = item;
      count++;
    }

    /**
     * Removes an item from this page's array at a specific offset.
     * Shifts existing items to the left.
     *
     * @param offset The index in the `items` array to remove.
     * @return The item that was removed.
     */
    E removeItem(int offset) {
      if (offset < 0 || offset >= count) {
        throw new IndexOutOfBoundsException("Internal remove error: offset " + offset + ", count " + count);
      }
      E item = items[offset];
      int numToMove = count - offset - 1;
      if (numToMove > 0) {
        System.arraycopy(items, offset + 1, items, offset, numToMove);
      }
      items[count - 1] = null;
      count--;
      return item;
    }
  }

  /**
   * A private static inner class that holds information about a page,
   * used as an entry in the `pageIndex`.
   */
  private static class IndexEntry<E> {
    /**
     * A direct reference to the page object.
     */
    final Page<E> page;

    /**
     * The logical index of the *first* item on this page (items[0]).
     */
    Integer logicalIndex;

    /**
     * The number of items currently stored on this page.
     */
    int count;

    /**
     * Constructs a new index entry.
     *
     * @param page         The page to reference.
     * @param logicalIndex The logical index of the first item on this page.
     * @param count        The current item count of this page.
     */
    IndexEntry(Page<E> page, int logicalIndex, int count) {
      this.page = page;
      this.logicalIndex = logicalIndex;
      this.count = count;
    }
  }

  /**
   * A simple private inner class to return two values (page and offset)
   * from the `findPageForLogicalIndex` method.
   *
   * @param <T> The type of element held in the page.
   */
  private class PageInfo<T> {
    /**
     * The page found.
     */
    final Page<T> page;

    /**
     * The calculated offset within the page's array.
     */
    final int offset;

    /**
     * Constructs a new PageInfo.
     *
     * @param page   The page.
     * @param offset The offset.
     */
    PageInfo(Page<T> page, int offset) {
      this.page = page;
      this.offset = offset;
    }
  }

  /**
   * The private implementation of the `ListIterator` interface.
   * * This iterator is "fail-fast" and will throw a
   * ConcurrentModificationException if the list is structurally
   * modified by any method other than the iterator's own `add` or `remove`
   * methods.
   */
  private class PagedListIterator implements ListIterator<E> {

    /**
     * The page that contains the *next* element to be returned by `next()`.
     */
    private Page<E> currentPage;

    /**
     * The offset within `currentPage` of the *next* element to be
     * returned by `next()`.
     */
    private int pageOffset;

    /**
     * The logical index of the *next* element to be returned by `next()`.
     */
    private int logicalIndex;

    /**
     * The logical index of the element last returned by `next()` or
     * `previous()`. Used by `set()` and `remove()`.
     * Set to -1 if no such element exists.
     */
    private int lastItemIndex;

    /**
     * The direction of the last move, to validate `set()` and `remove()` calls.
     */
    private Direction lastDirection;

    /**
     * The value of `modificationCount` that this iterator expects.
     * Used to detect concurrent modifications.
     */
    private int expectedModificationCount;

    /**
     * Constructs a new iterator starting at the given logical position.
     * This operation is fast ($O(\log N_{\text{pages}})$) due to
     * `findPageForLogicalIndex`.
     * * This method performs the following steps:
     * 1. Use findPageForLogicalIndex(pos) to get the starting PageInfo.
     * 2. Initialize currentPage and pageOffset from the PageInfo.
     * 3. Initialize logicalIndex to pos.
     * 4. Initialize lastItemIndex to -1, lastDirection to NONE.
     * 5. Initialize expectedModificationCount to modificationCount.
     *
     * @param pos The logical index to start at.
     */
    PagedListIterator(int pos) {
    	PageInfo<E> info = findPageForLogicalIndex(pos);
    	this.pageOffset = info.offset;
    	this.currentPage = info.page;
    	this.logicalIndex = pos;
    	this.lastItemIndex = -1;
    	this.lastDirection = Direction.NONE;
    	this.expectedModificationCount = modificationCount;
    	
      // TODO
    }

    /**
     * Checks for concurrent modification.
     *
     * @throws ConcurrentModificationException if the list has been modified
     *                                         externally.
     */
    private void checkComodification() {
      if (expectedModificationCount != modificationCount) {
        throw new ConcurrentModificationException();
      }
    }

    /**
     * Returns `true` if this list iterator has more elements when
     * traversing the list in the forward direction.
     * * This method performs the following steps:
     * 1. Check for comodification.
     * 2. Check if logicalIndex is less than totalSize.
     */
    @Override
    public boolean hasNext() {
    	checkComodification();
    	if(logicalIndex < totalSize) {
    		return true;
    	}
    	return false;
    }

    /**
     * Returns the next element in the list and advances the cursor
     * position. Remember to check for comodification.
     */
    @Override
    public E next() {
    	checkComodification();
    	if(hasNext() == false) {
    		throw new NoSuchElementException();
    	}
    	E item = currentPage.items[pageOffset];
    	logicalIndex++;
    	pageOffset++;
    	if(pageOffset == currentPage.count) {
    		currentPage = currentPage.next;
    		pageOffset = 0;
    	}
    	lastItemIndex = logicalIndex - 1;
    	lastDirection = Direction.NEXT;
    	return item;
    }

    /**
     * Returns `true` if this list iterator has more elements when
     * traversing the list in the reverse direction. Remember to check for comodification.
     */
    @Override
    public boolean hasPrevious() {
    	checkComodification();
    	if(logicalIndex > 0) {
    		return true;
    	}
    	return false;
    }

    /**
     * Returns the previous element in the list and moves the cursor
     * position backwards. Remember to check for comodification.
     */
    @Override
    public E previous() {
    	checkComodification();
    	if(hasPrevious() == false) {
    		throw new NoSuchElementException();
    	}
    	logicalIndex --;
    	pageOffset --;
    	if(pageOffset < 0) {
    		currentPage = currentPage.prev;
    		pageOffset = currentPage.count - 1;
    	}
    	E item = currentPage.items[pageOffset];
		lastItemIndex = logicalIndex;
		lastDirection = Direction.PREVIOUS;
		return item;
    }

    /**
     * Returns the index of the element that would be returned by a
     * subsequent call to `next()`. Remember to check for comodification.
     */
    @Override
    public int nextIndex() {
    	checkComodification();
    	return logicalIndex;
    }

    /**
     * Returns the index of the element that would be returned by a
     * subsequent call to `previous()`. Remember to check for comodification.
     */
    @Override
    public int previousIndex() {
    	checkComodification();
    	return logicalIndex - 1;
    }

    /**
     * Removes from the list the last element that was returned by
     * `next()` or `previous()`.
     * * This operation delegates to the outer class's `remove(int)` method,
     * which runs in $O(N_{\text{pages}})$ time. The iterator then
     * re-synchronizes its position in $O(\log N_{\text{pages}})$ time.
     * * This method performs the following steps:
     * 1. Check for comodification.
     * 2. Check for IllegalStateException.
     * 3. Call the outer class's remove: IndexedPagedList.this.remove(lastItemIndex);
     * 4. Update iterator state
     * 5. Update modification counts
     * 6. Reset lastDirection to NONE and lastItemIndex to -1.
     *
     * @throws IllegalStateException if `next()` or `previous()` have not
     *                               been called, or `remove()` or `add()`
     *                               have been called since the last move.
     */
    @Override
    public void remove() {
    	checkComodification();
    	if(lastDirection == Direction.NONE) {
    		throw new IllegalStateException();
    	}
    	IndexedPagedList.this.remove(lastItemIndex);
    	if(lastDirection == Direction.NEXT) {
    		logicalIndex--;
    	}
    	PageInfo<E> info = findPageForLogicalIndex(logicalIndex);
    	this.currentPage = info.page;
    	this.pageOffset = info.offset;
    	expectedModificationCount = modificationCount;
    	lastDirection = Direction.NONE;
    	lastItemIndex = -1;
    }

    /**
     * Replaces the last element returned by `next()` or `previous()`
     * with the specified element.
     * * This operation is $O(1)$ after finding the page in
     * $O(\log N_{\text{pages}})$ time.
     * * This method performs the following steps:
     * 1. Check for comodification.
     * 2. Check for Exceptions.
     * 3. Find the page/offset for lastItemIndex using findPageForLogicalIndex.
     * 4. Set the item in that page's array.
     * 5. Do NOT change modificationCount.
     *
     *
     * @throws IllegalStateException if `next()` or `previous()` have not
     *                               been called, or `remove()` or `add()`
     *                               have been called since the last move.
     * @throws NullPointerException  if the specified element is null.
     */
    @Override
    public void set(E item) {
    	checkComodification();
    	if(lastDirection == Direction.NONE) {
    		throw new IllegalStateException();
    	}
    	if(item == null) {
    		throw new NullPointerException();
    	}
    	PageInfo<E> info = findPageForLogicalIndex(lastItemIndex);
    	int offset = info.offset;
    	Page<E> page = info.page;
    	
    	page.items[offset] = item;
    }

    /**
     * Inserts the specified element into the list at the iterator's
     * current position.
     * * This operation delegates to the outer class's `add(int, E)` method,
     * which runs in $O(N_{\text{pages}})$ time. The iterator then
     * re-synchronizes its position in $O(\log N_{\text{pages}})$ time.
     * * This method performs the following steps:
     * 1. Check for comodification.
     * 2. Check for Exceptions.
     * 3. Call the outer class's add: IndexedPagedList.this.add(logicalIndex, item);
     * 4. Update iterator state
     * 5. Update modification counts
     * 6. Reset lastDirection to NONE and lastItemIndex to -1.
     *
     * @throws NullPointerException if the specified element is null.
     */
    @Override
    public void add(E item) {
    	checkComodification();
    	if(item == null) {
    		throw new NullPointerException();
    	}
		IndexedPagedList.this.add(logicalIndex, item);
		logicalIndex++;
		expectedModificationCount++;
		PageInfo<E> info = findPageForLogicalIndex(logicalIndex);
		this.currentPage = info.page;
		this.pageOffset = info.offset;
		lastDirection = Direction.NONE;
		lastItemIndex = -1;
    }

    /**
     * Enum to track the last operation (`next` or `previous`)
     * for `remove()` and `set()` validation.
     */
    private enum Direction {
      NONE, NEXT, PREVIOUS
    }
  }
}
